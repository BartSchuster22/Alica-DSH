"""Bounded Doghouse DSH successor; no legacy executor or LLM authority."""
